// Carrusel automático con transición suave
const slides = document.querySelectorAll('.slides img');
let current = 0;

// Activamos la primera imagen
slides[current].classList.add('active');

function showNextSlide() {
    slides[current].classList.remove('active');
    current = (current + 1) % slides.length;
    slides[current].classList.add('active');
}

setInterval(showNextSlide, 6000); // cambia cada 6 segundos
