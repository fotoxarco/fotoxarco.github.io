La asociación de fotografía Fotoxarco ha iniciado este proyecto para darse a conocer y compartir, una web.
